import heapq

def heuristic(a, b):
    """Calculate the Manhattan distance between two points."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def best_first_search_robot(grid, start, goal):
    rows, cols = len(grid), len(grid[0])
    visited = set()
    pq = [(heuristic(start, goal), start)]

    while pq:
        _, current = heapq.heappop(pq)
        print("Visiting:", current)

        if current == goal:
            print("Goal reached!")
            return

        visited.add(current)
        x, y = current

        for dx, dy in [(-1,0), (1,0), (0,-1), (0,1)]:
            nx, ny = x + dx, y + dy

            if 0 <= nx < rows and 0 <= ny < cols and grid[nx][ny] == 0:
                neighbor = (nx, ny)
                if neighbor not in visited:
                    heapq.heappush(pq, (heuristic(neighbor, goal), neighbor))

# ---------- USER INPUT ----------

# Get grid size
rows = int(input("Enter number of rows: "))
cols = int(input("Enter number of columns: "))

# Input grid values
print("Enter grid values row by row (0 for free, 1 for obstacle):")
grid = []
for i in range(rows):
    row = list(map(int, input(f"Row {i + 1}: ").split()))
    while len(row) != cols:
        print("Invalid row length. Please enter exactly", cols, "values.")
        row = list(map(int, input(f"Row {i + 1}: ").split()))
    grid.append(row)

# Input start and goal positions
start_x, start_y = map(int, input("Enter start position (row col): ").split())
goal_x, goal_y = map(int, input("Enter goal position (row col): ").split())
start = (start_x, start_y)
goal = (goal_x, goal_y)

# Call the search
best_first_search_robot(grid, start, goal)
"""Enter number of columns: 4
Enter grid values row by row (0 for free, 1 for obstacle):
Row 1: 0 0 0 1
Row 2: 1 0 1 0
Row 3: 0 0 0 0
Enter start position (row col): 0 0
Enter goal position (row col): 2 3"""