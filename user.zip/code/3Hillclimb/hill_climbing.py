import tkinter as tk
import time

class State:
    """Represents a state in the search space."""

    def __init__(self, data, prev=None):
        self.data = data  # Tuple representing the board
        self.prev = prev  # Previous state reference

    def __eq__(self, other):
        return isinstance(other, State) and self.data == other.data

    def __hash__(self):
        return hash(self.data)

    def __str__(self):
        return "\n".join([" ".join(map(str, self.data[i:i+3])) for i in range(0, 9, 3)])

    def manhattan_distance(self):
        """Manhattan distance heuristic."""
        goal = (1, 2, 3, 4, 5, 6, 7, 8, 0)
        distance = 0
        for i, value in enumerate(self.data):
            if value != 0:
                goal_index = goal.index(value)
                distance += abs(goal_index // 3 - i // 3) + abs(goal_index % 3 - i % 3)
        return distance

    def hamming_distance(self):
        """Counts misplaced tiles compared to the goal state."""
        goal = (1, 2, 3, 4, 5, 6, 7, 8, 0)
        return sum(1 for i, v in enumerate(self.data) if v != 0 and v != goal[i])

    def next(self):
        """Generate next possible states (valid moves)."""
        neighbors = []
        zero_index = self.data.index(0)
        row, col = zero_index // 3, zero_index % 3
        moves = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}

        for _, (dr, dc) in moves.items():
            new_row, new_col = row + dr, col + dc
            if 0 <= new_row < 3 and 0 <= new_col < 3:
                new_index = new_row * 3 + new_col
                new_data = list(self.data)
                new_data[zero_index], new_data[new_index] = new_data[new_index], new_data[zero_index]
                neighbors.append(State(tuple(new_data), self))

        return neighbors


class Searcher:
    """Searcher that manipulates the searching process."""

    def __init__(self, start, goal, gui):
        self.start = start
        self.goal = goal
        self.gui = gui  # Link to Tkinter GUI

    def print_path(self, state):
        """Prints the path from start to goal."""
        path = []
        while state:
            path.append(state)
            state = state.prev
        path.reverse()

        for step in path:
            self.gui.update_board(step.data)
            time.sleep(0.5)

    def steepest_ascent_hill_climbing(self):
        """Run steepest ascent hill climbing search."""
        stack = [self.start]

        while stack:
            state = stack.pop()
            self.gui.update_board(state.data)
            time.sleep(0.5)

            if state == self.goal:
                self.print_path(state)
                self.gui.display_message("Solution Found!")
                return

            h_val = state.manhattan_distance() + state.hamming_distance()
            next_state = None
            for s in state.next():
                h_val_next = s.manhattan_distance() + s.hamming_distance()
                if h_val_next < h_val:
                    next_state = s
                    h_val = h_val_next

            if next_state:
                stack.append(next_state)
            else:
                self.gui.display_message("Cannot Find Solution")
                return


class PuzzleGUI:
    """Tkinter-based 8-puzzle solver visualization."""

    def __init__(self, root, start_state, goal_state):
        self.root = root
        self.start_state = start_state
        self.goal_state = goal_state

        self.root.title("8-Puzzle Solver")
        self.buttons = [[None] * 3 for _ in range(3)]

        self.frame = tk.Frame(self.root)
        self.frame.pack()

        for i in range(3):
            for j in range(3):
                self.buttons[i][j] = tk.Button(
                    self.frame, text="", font=("Arial", 20), width=5, height=2
                )
                self.buttons[i][j].grid(row=i, column=j)

        self.label = tk.Label(self.root, text="", font=("Arial", 16), fg="blue")
        self.label.pack()

        self.solve_button = tk.Button(self.root, text="Solve", font=("Arial", 14), command=self.start_search)
        self.solve_button.pack()

        self.update_board(self.start_state.data)

    def update_board(self, state_data):
        """Updates the board to reflect the current state."""
        for i in range(3):
            for j in range(3):
                value = state_data[i * 3 + j]
                self.buttons[i][j].config(text=str(value) if value != 0 else " ")

        self.root.update_idletasks()

    def display_message(self, message):
        """Displays a message after search completes."""
        self.label.config(text=message)

    def start_search(self):
        """Starts the search process."""
        searcher = Searcher(self.start_state, self.goal_state, self)
        searcher.steepest_ascent_hill_climbing()


# Main function to run the Tkinter GUI
if __name__ == "__main__":
    start_state = State((1, 2, 3, 4, 5, 6, 7, 0, 8))  # Example initial state
    goal_state = State((1, 2, 3, 4, 5, 6, 7, 8, 0))  # Goal state

    root = tk.Tk()
    gui = PuzzleGUI(root, start_state, goal_state)
    root.mainloop()
    
    '''
    Put the start state in the stack.

While there’s something in the stack:

Take the top state from the stack.

Show the current state on the GUI.

If the state is the goal:

Show the path from start to goal.

Display "Solution Found".

Exit.

Get the heuristic value of the current state:
h = manhattan(state) + hamming(state).

Set next_state = None.

For each possible move (neighbor) from the current state:

Calculate its heuristic value: h_next = manhattan(neighbor) + hamming(neighbor).

If h_next is better (smaller) than the current h:

Set next_state to this neighbor.

Update h to h_next.

If you found a better neighbor (next_state is not None):

Add next_state to the stack.

If no better neighbor was found:

Show "Cannot Find Solution".

Exit.


    '''