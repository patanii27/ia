# pip install scikit-learn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def similarity_score(text1, text2):
    # Convert the text to tf-idf vectors
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([text1, text2])
    
    # Calculate cosine similarity
    similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
    
    return similarity[0][0]

# Take input from user
text1 = input("Enter the first sentence: ")
text2 = input("Enter the second sentence: ")

# Compute similarity
similarity = similarity_score(text1, text2)
print(f"\nCosine Similarity: {similarity:.4f}")


#text1 = "I love programming in Python"#
#ext2 = "Python programming is amazing"#