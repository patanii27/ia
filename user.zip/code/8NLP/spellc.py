# pip install pyspellchecker
from spellchecker import SpellChecker

def spell_check(text):
    # Initialize the spell checker
    spell = SpellChecker()
    
    # Split the input text into words
    words = text.split()
    
    # Find words that are misspelled
    misspelled = spell.unknown(words)
    
    # Correct the misspelled words
    corrected = {}
    for word in misspelled:
        corrected[word] = spell.correction(word)
    
    return corrected

# Take input from the user
text = input("Enter a sentence for spell checking: ")
corrections = spell_check(text)

# Display the results
if corrections:
    print("\nMisspelled Words and Suggestions:")
    for wrong, right in corrections.items():
        print(f"{wrong} → {right}")
else:
    print("\nNo spelling errors found!")


# I am lerning Pythn progamming#