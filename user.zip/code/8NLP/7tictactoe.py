import tkinter as tk  # Importing the tkinter module for GUI
from tkinter import messagebox  # Importing messagebox to display winner or draw messages

# Function to check if there's a winner or a draw
def check_winner():
    # List of all winning combinations (index positions of buttons in the grid)
    winning_combinations = [(0, 1, 2), (3, 4, 5), (6, 7, 8),
                            (0, 3, 6), (1, 4, 7), (2, 5, 8),
                            (0, 4, 8), (2, 4, 6)]
    
    # Loop through each winning combination and check if any have the same player symbol (X or O)
    for x, y, z in winning_combinations:
        if buttons[x]["text"] == buttons[y]["text"] == buttons[z]["text"] != "":
            # If a player wins, show the winner message and reset the board
            messagebox.showinfo("Game Over", f"Player {buttons[x]['text']} wins!")
            reset_board()
            return  # End the function once a winner is found
    
    # If all spots are filled and no winner, it's a draw
    if all(button["text"] != "" for button in buttons):
        messagebox.showinfo("Game Over", "It's a draw!")
        reset_board()

# Function to reset the game board (clear all buttons and make them clickable again)
def reset_board():
    for button in buttons:
        button.config(text="", state=tk.NORMAL)  # Reset button text to empty and make it clickable again

# Function that runs when a button is clicked
def on_click(index):
    global turn  # Use the global turn variable to keep track of who's playing
    if buttons[index]["text"] == "":  # If the clicked button is empty
        buttons[index].config(text=turn)  # Set the button's text to the current player's symbol (X or O)
        turn = "O" if turn == "X" else "X"  # Switch the turn to the other player (X -> O or O -> X)
        check_winner()  # Check if the move resulted in a win or draw

# Main GUI setup
root = tk.Tk()  # Create a new Tkinter window
root.title("Tic Tac Toe")  # Set the window title
turn = "X"  # The first player is X

# Create 9 buttons for the 3x3 Tic Tac Toe grid, each button will trigger on_click when clicked
buttons = [tk.Button(root, text="", font="Arial 20", width=5, height=2, command=lambda i=i: on_click(i))
           for i in range(9)]  # Generate 9 buttons and pass their index to the on_click function

# Arrange the buttons in a 3x3 grid layout (row 0-2, column 0-2)
for i, button in enumerate(buttons):
    button.grid(row=i//3, column=i%3)

root.mainloop()  # Start the Tkinter event loop to run the GUI
