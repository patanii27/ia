import spacy

# Load the spaCy English model
nlp = spacy.load("en_core_web_sm")

def pos_tagging(text):
    doc = nlp(text)
    results = []
    for token in doc:
        results.append((token.text, token.pos_, token.tag_, spacy.explain(token.tag_)))
    return results

# Take input from the user
text = input("Enter a sentence for POS tagging: ")
tagged = pos_tagging(text)

print("\nToken".ljust(15), "POS".ljust(10), "Tag".ljust(10), "Description")
print("-" * 60)
for token in tagged:
    print(f"{token[0].ljust(15)}{token[1].ljust(10)}{token[2].ljust(10)}{token[3]}")


#"The quick brown fox jumps over the lazy dog"#