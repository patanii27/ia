# pip install pyspellchecker

from spellchecker import SpellChecker

def spell_check(text):
    # Initialize the spell checker
    spell = SpellChecker()
    
    # Split the input text into words
    words = text.split()
    
    # Find words that are misspelled
    misspelled = spell.unknown(words)
    
    # Correct the misspelled words
    corrected = {}
    for word in misspelled:
        corrected[word] = spell.correction(word)
    
    return corrected

# Get input from the user
user_input = input("Enter text to check spelling: ")
corrections = spell_check(user_input)

# Show results
if corrections:
    print("Corrections:")
    for wrong, right in corrections.items():
        print(f"  {wrong} → {right}")
else:
    print("No spelling mistakes found.")


"""
Enter text to check spelling: I definately recieved teh pakage yestarday

Enter text to check spelling: I am verry hapy with the reslts.
"""