#pip install scikit-learn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def similarity_score(text1, text2):
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([text1, text2])
    similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
    return similarity[0][0]

# Take input from user
text1 = input("Enter first text: ")
text2 = input("Enter second text: ")

similarity = similarity_score(text1, text2)
print(f"Cosine Similarity: {similarity:.4f}")
"""

Enter first text: I enjoy watching movies on weekends.
Enter second text: On weekends, I love watching films.
Cosine Similarity: 0.4316

Enter first text: i love programming in python
Enter second text: python programming is amazing
Cosine Similarity: 0.3361

Enter first text: I love playing basketball on weekends.
Enter second text: Python is a powerful programming language.
Cosine Similarity: 0.0000


"""