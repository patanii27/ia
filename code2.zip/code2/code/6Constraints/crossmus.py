# Take grid size from user
grid_size = int(input("Enter grid size (e.g. 5 for 5x5): "))
if grid_size <= 0:
    print("Grid size must be a positive number.")
    exit()

# Take grid input
print(f"Enter the {grid_size}x{grid_size} grid (use '-' for empty, '+' for blocked):")
g = []
for i in range(grid_size):
    row = input(f"Row {i+1}: ").strip()
    if len(row) != grid_size or any(ch not in ('+', '-') for ch in row):
        print("Invalid row. Please enter exactly", grid_size, "characters using '+' or '-' only.")
        exit()
    g.append(list(row))

# Take words input
words_input = input("Enter words separated by commas (e.g. CAT,TOP): ")
w = [word.strip().upper() for word in words_input.split(",")]

# Solver function using backtracking
def solve(i=0):
    if i == len(w):
        print("\nSolved Grid:")
        print('\n'.join(''.join(r) for r in g))
        return True
    for r in range(grid_size):
        for c in range(grid_size):
            for h in (1, 0):  # h=1 horizontal, h=0 vertical
                pos = []
                ok = True
                for j, ch in enumerate(w[i]):
                    x, y = (r, c + j) if h else (r + j, c)
                    # Check if out of bounds or invalid placement
                    if x >= grid_size or y >= grid_size or g[x][y] not in ('-', ch):
                        ok = False
                        break
                    if g[x][y] == '-':
                        pos.append((x, y, ch))
                if not ok:
                    continue
                # Place the word
                for x, y, ch in pos:
                    g[x][y] = ch
                if solve(i + 1):
                    return True
                # Backtrack if needed
                for x, y, _ in pos:
                    g[x][y] = '-'
    return False

# Run the solver
if not solve():
    print("No solution found.")

'''

Enter grid size (e.g. 5 for 5x5): 5
Enter the 5x5 grid (use '-' for empty, '+' for blocked):
Row 1: +-+++
Row 2: +-+++
Row 3: +---+
Row 4: +-+++
Row 5: +++++
Enter words separated by commas (e.g. CAT,TOP): CAT,TOP

Solved Grid:
+C+++
+A+++
+TOP+
+-+++
+++++

'''