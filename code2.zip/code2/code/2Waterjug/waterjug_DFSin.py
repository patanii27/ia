def water_jug_dfs(jug1, jug2, target):
    visited = set()  # To avoid revisiting states (infinite loop prevention)
    
    def dfs(x, y, path):
        # Add the current state to the path
        path = path + [(x, y)]
        
        # Base case: solution found
        if x == target or y == target:
            print("Steps to reach the target:")
            for step in path:
                print(f"Jug1: {step[0]}, Jug2: {step[1]}")
            return True

        if (x, y) in visited:
            return False
        visited.add((x, y))

        # Generate all possible states
        return (dfs(jug1, y, path) or          # Fill Jug1
                dfs(x, jug2, path) or          # Fill Jug2
                dfs(0, y, path) or             # Empty Jug1
                dfs(x, 0, path) or             # Empty Jug2
                dfs(x - min(x, jug2 - y), y + min(x, jug2 - y), path) or  # Pour Jug1 -> Jug2
                dfs(x + min(y, jug1 - x), y - min(y, jug1 - x), path))    # Pour Jug2 -> Jug1
    
    if not dfs(0, 0, []):
        print("Target not reachable.")
        return False
    return True

# Get input from user
jug1_capacity = int(input("Enter capacity of Jug 1: "))
jug2_capacity = int(input("Enter capacity of Jug 2: "))
target_amount = int(input("Enter target amount: "))

print("\nDFS Solution:")
water_jug_dfs(jug1_capacity, jug2_capacity, target_amount)

"""
input:

Enter capacity of Jug 1: 4
Enter capacity of Jug 2: 3
Enter target amount: 2
"""