import heapq  # Import heapq module for implementing a priority queue (used in A* algorithm)

class RobotNavigator:
    def __init__(self, grid):
        # Initialize the navigator with a grid, where 'S' is the starting position, 
        # '.' are walkable areas, and '#' are obstacles, and 'G' represents goal positions.
        self.grid = grid
        self.rows = len(grid)  # Get the number of rows in the grid
        self.cols = len(grid[0]) if self.rows > 0 else 0  # Get the number of columns in the grid
        self.start_pos = self.find_position('S')  # Find the starting position ('S')
        self.goal_positions = self.find_all_positions('G')  # Find all goal positions ('G')
        
    def find_position(self, char):
        # Search for the first occurrence of the character in the grid and return its coordinates (i, j)
        for i in range(self.rows):
            for j in range(self.cols):
                if self.grid[i][j] == char:
                    return (i, j)
        return None  # If not found, return None
        
    def find_all_positions(self, char):
        # Search for all occurrences of the character in the grid and return their coordinates as a list
        positions = []
        for i in range(self.rows):
            for j in range(self.cols):
                if self.grid[i][j] == char:
                    positions.append((i, j))
        return positions
        
    class Node:
        def __init__(self, position, parent=None):
            # Node represents a state in the search, containing position, parent node, and cost info.
            self.position = position  # Current position in the grid
            self.parent = parent  # The parent node from which this node was reached
            self.g = 0 if parent is None else parent.g + 1  # g: the cost to reach this position from the start
            self.h = 0  # h: the heuristic cost, will be calculated based on Manhattan distance to the closest goal
            self.calculate_heuristic()  # Calculate the heuristic for this node
            
        def calculate_heuristic(self):
            # Manhattan distance heuristic: for multiple goals, use the minimum distance to any goal
            if not self.parent or not hasattr(self.parent, 'goal_positions'):
                return 0  # If no parent or no goal positions, set heuristic to 0
            min_dist = float('inf')  # Initialize to infinity
            for goal in self.parent.goal_positions:
                # Compute the Manhattan distance from the current position to the goal
                dist = abs(self.position[0] - goal[0]) + abs(self.position[1] - goal[1])
                if dist < min_dist:
                    min_dist = dist  # Update minimum distance if a closer goal is found
            self.h = min_dist  # Set the heuristic to the minimum distance
        
        def is_goal(self, goal_positions):
            # Check if the current position is one of the goal positions
            return self.position in goal_positions
            
        def get_neighbors(self, grid, rows, cols):
            # Get all the valid neighboring positions that can be moved to (Up, Down, Left, Right)
            neighbors = []
            i, j = self.position  # Current position
            moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # Directions: Up, Down, Left, Right
            
            for di, dj in moves:
                ni, nj = i + di, j + dj  # New position after applying the move
                if 0 <= ni < rows and 0 <= nj < cols and grid[ni][nj] != '#':
                    # If the new position is within bounds and not an obstacle, add it as a neighbor
                    neighbors.append(self.__class__((ni, nj), self))  # Add the neighbor node
            return neighbors
            
        def __lt__(self, other):
            # Comparison function used by heapq to prioritize nodes based on f = g + h (A* cost)
            return (self.g + self.h) < (other.g + other.h)
            
        def __eq__(self, other):
            # Nodes are considered equal if they have the same position
            return self.position == other.position
            
        def __hash__(self):
            # Nodes are hashed based on their position for quick lookup in sets
            return hash(self.position)

    def solve(self):
        # Main method to solve the navigation problem using A* algorithm
        if not self.start_pos or not self.goal_positions:
            # If no start or goal positions, return None
            return None
            
        start_node = self.Node(self.start_pos)  # Create the start node
        start_node.goal_positions = self.goal_positions  # Pass goal positions to the node
        
        open_set = []  # Open set (priority queue) to explore nodes, ordered by f = g + h
        heapq.heappush(open_set, start_node)  # Add the start node to the open set
        closed_set = set()  # Closed set to keep track of explored nodes
        
        while open_set:
            # While there are nodes to explore
            current = heapq.heappop(open_set)  # Pop the node with the lowest f value (g + h)
            
            if current.is_goal(self.goal_positions):
                # If the current node is a goal, backtrack to reconstruct the path
                path = []
                while current.parent is not None:
                    path.append(current.position)  # Add the current position to the path
                    current = current.parent  # Move to the parent node
                path.append(current.position)  # Add the start position
                path.reverse()  # Reverse the path to show it from start to goal
                return path  # Return the path from start to goal
                
            closed_set.add(current)  # Add the current node to the closed set
            
            # For each neighbor of the current node
            for neighbor in current.get_neighbors(self.grid, self.rows, self.cols):
                if neighbor in closed_set:
                    continue  # Skip if the neighbor has already been explored
                
                neighbor.goal_positions = self.goal_positions  # Pass goal positions to the neighbor node
                neighbor.calculate_heuristic()  # Recalculate the heuristic for the neighbor
                
                if neighbor not in open_set:
                    heapq.heappush(open_set, neighbor)  # Add the neighbor to the open set
                else:
                    # If the neighbor is already in the open set, check if a better path is found
                    for node in open_set:
                        if node == neighbor and node.g > neighbor.g:
                            node.g = neighbor.g  # Update the cost if the neighbor has a better path
                            node.parent = neighbor.parent  # Update the parent node
                            heapq.heapify(open_set)  # Re-heapify the open set
                            break
        return None  # If no path is found, return None

# Example usage:
grid = [
    ['S', '.', '.', '#', '.'],  # Starting position 'S'
    ['.', '#', '.', '.', '.'],  # Open paths ('.')
    ['.', '#', '#', '.', '#'],  # Obstacles ('#')
    ['.', '.', '.', '.', 'G']   # Goal positions ('G')
]

navigator = RobotNavigator(grid)  # Initialize the navigator with the grid
path = navigator.solve()  # Solve the problem using A*

if path:
    print("Path found with", len(path)-1, "moves:")  # If a path is found, print it
    for i, pos in enumerate(path):
        print(f"Step {i}: {pos}")  # Print each step of the path
else:
    print("No path found to the goal")  # If no path is found, print this message
