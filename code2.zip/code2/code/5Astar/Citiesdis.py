import heapq  # Importing the heapq module, which provides a priority queue implementation

class CityPathFinder:
    # The main class to find the shortest path between two cities using A* algorithm (Dijkstra-like in this case)
    def __init__(self, graph):
        # The graph represents a city network, where keys are city names and values are dictionaries 
        # representing neighboring cities and their distances
        self.graph = graph
        
    class Node:
        # A class to represent a node (city) in the pathfinding process. Each node has:
        # - a city name
        # - a parent (the node from which this node was reached)
        # - a distance from the start city (g)
        # - a heuristic value (h, but it's set to 0 in this case)
        def __init__(self, city, parent=None, distance_from_parent=0):
            self.city = city
            self.parent = parent
            # g represents the cost from the start node to the current node
            self.g = 0 if parent is None else parent.g + distance_from_parent
            self.h = 0  # h represents the heuristic value (set to 0 here, making it equivalent to Dijkstra's algorithm)

        def calculate_heuristic(self, goal_city, heuristic_table=None):
            # This function calculates the heuristic (h) for the node. In a real implementation, this would
            # use actual data (e.g., coordinates). For simplicity, we set h = 0, making this equivalent to Dijkstra's.
            self.h = 0

        def get_neighbors(self, graph):
            # This function generates neighboring nodes (cities) from the graph
            neighbors = []
            for neighbor, distance in graph[self.city].items():
                neighbors.append(self.__class__(neighbor, self, distance))  # Create a new node for each neighbor
            return neighbors

        def __lt__(self, other):
            # Comparison operator used by heapq to compare nodes based on their f value (f = g + h)
            # It's used to ensure that the node with the smallest f value (g + h) gets processed first in the heap.
            return (self.g + self.h) < (other.g + other.h)

        def __eq__(self, other):
            # Nodes are equal if they have the same city
            return self.city == other.city

        def __hash__(self):
            # Each node needs to be hashable so that it can be used in sets and dictionaries
            return hash(self.city)

    def find_shortest_path(self, start_city, goal_city):
        # This function finds the shortest path from the start city to the goal city using the A* algorithm (or Dijkstra's)
        
        if start_city not in self.graph or goal_city not in self.graph:
            # If either the start city or the goal city is not in the graph, return None
            return None
            
        # Create the start node and calculate its heuristic (h)
        start_node = self.Node(start_city)
        start_node.calculate_heuristic(goal_city)
        
        # Initialize the open set (min-heap) to store nodes to explore and the closed set to store explored nodes
        open_set = []  
        open_set_dict = {}  # A dictionary to efficiently check for duplicate nodes in the open set
        heapq.heappush(open_set, start_node)  # Push the start node into the open set
        open_set_dict[start_city] = start_node
        
        closed_set = set()  # A set to track the nodes we've already processed
        
        while open_set:
            # While there are nodes to process, we explore the one with the lowest f value (g + h)
            current = heapq.heappop(open_set)  # Get the node with the lowest f value
            del open_set_dict[current.city]  # Remove the current city from the dictionary to prevent duplicates
            
            if current.city == goal_city:
                # If we reach the goal city, construct the path
                path = []
                distances = []
                while current.parent is not None:
                    path.append(current.city)  # Add the current city to the path
                    distances.append(current.g - current.parent.g)  # Add the distance from the parent to the path
                    current = current.parent  # Move to the parent node
                path.append(current.city)  # Add the start city (the last parent is None)
                path.reverse()  # Reverse the path to show it from start to goal
                distances.reverse()  # Reverse the distances to match the path order
                return path, distances, current.g  # Return the path, segment distances, and the total cost
                
            closed_set.add(current)  # Mark the current node as explored
            
            # Explore all neighbors of the current node
            for neighbor in current.get_neighbors(self.graph):
                if neighbor in closed_set:
                    # If the neighbor is already processed, skip it
                    continue
                
                neighbor.calculate_heuristic(goal_city)  # Calculate the heuristic for the neighbor
                
                # If the neighbor isn't in the open set, add it
                if neighbor.city not in open_set_dict:
                    heapq.heappush(open_set, neighbor)  # Add the neighbor to the heap
                    open_set_dict[neighbor.city] = neighbor  # Add the neighbor to the dictionary
                else:
                    # If the neighbor is already in the open set, check if we found a better path
                    existing_node = open_set_dict[neighbor.city]
                    if neighbor.g < existing_node.g:
                        # If the neighbor's new g value is smaller, update it
                        open_set.remove(existing_node)  # Remove the old version of the node
                        heapq.heapify(open_set)  # Re-heapify the heap after removal
                        heapq.heappush(open_set, neighbor)  # Push the updated neighbor into the heap
                        open_set_dict[neighbor.city] = neighbor  # Update the dictionary with the new node
                    
        return None, None, 0  # If no path is found, return None

# Example usage
city_graph = {
    'A': {'B': 5, 'C': 10},
    'B': {'A': 5, 'D': 3, 'E': 8},
    'C': {'A': 10, 'F': 7},
    'D': {'B': 3, 'E': 2},
    'E': {'B': 8, 'D': 2, 'F': 4, 'G': 5},
    'F': {'C': 7, 'E': 4, 'G': 6},
    'G': {'E': 5, 'F': 6}
}

# Create a pathfinder instance with the city graph
finder = CityPathFinder(city_graph)
start = 'A'
goal = 'E'

# Find the shortest path from start to goal
path, distances, total_distance = finder.find_shortest_path(start, goal)

if path:
    # If a path is found, print it
    print(f"Shortest path from {start} to {goal}:")
    for i in range(len(path)-1):
        print(f"{path[i]} --({distances[i]})--> ", end='')  # Print each segment of the path with distances
    print(path[-1])  # Print the last city in the path
    print(f"Total distance: {total_distance}")  # Print the total distance of the path
else:
    print(f"No path found from {start} to {goal}")  # If no path is found, print this message
