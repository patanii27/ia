import networkx as nx
import matplotlib.pyplot as plt

def draw_graph(edges, solution_path, title):
    G = nx.DiGraph()
    G.add_edges_from(edges)

    pos = nx.spring_layout(G, seed=42)
    plt.figure(figsize=(10, 6))

    nx.draw(G, pos, with_labels=True, node_color='lightblue', edge_color='gray', node_size=3000, font_size=10)

    solution_edges = [(solution_path[i], solution_path[i + 1]) for i in range(len(solution_path) - 1)]
    nx.draw(G, pos, edgelist=solution_edges, edge_color='red', width=2)

    plt.title(title)
    plt.show()

def water_jug_dfs(capacity1, capacity2, target):
    stack = [(0, 0)]
    visited = set()
    path = []
    edges = []

    while stack:
        a, b = stack.pop()

        if (a, b) in visited:
            continue

        visited.add((a, b))
        path.append((a, b))

        if a == target or b == target:
            draw_graph(edges, path, "DFS Search Tree")
            return path

        next_states = [
            (capacity1, b),  # Fill Jug 1
            (a, capacity2),  # Fill Jug 2
            (0, b),  # Empty Jug 1
            (a, 0),  # Empty Jug 2
            (a - min(a, capacity2 - b), b + min(a, capacity2 - b)),  # Pour Jug 1 → Jug 2
            (a + min(b, capacity1 - a), b - min(b, capacity1 - a))   # Pour Jug 2 → Jug 1
        ]

        for state in next_states:
            if state not in visited:
                edges.append(((a, b), state))
                stack.append(state)

    return None

# Example Usage
jug1_capacity = 4
jug2_capacity = 3
target_amount = 2

print("DFS Solution Path:", water_jug_dfs(jug1_capacity, jug2_capacity, target_amount))
