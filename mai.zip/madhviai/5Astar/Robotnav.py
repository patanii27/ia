import heapq
import matplotlib.pyplot as plt
import numpy as np
import time


# Fixed GridState class
class GridState:
    def __init__(self, x, y, cost, path):  # ✅ Correct method name
        self.x = x
        self.y = y
        self.cost = cost
        self.path = path  # Store the path to visualize movement

    def __lt__(self, other):  # ✅ Correct method name for priority queue comparison
        return self.cost < other.cost


# Best First Search for Robot Navigation with visualization
def best_first_search_robot(grid, start, goal):
    pq = []
    heapq.heappush(pq, GridState(start[0], start[1], 0, [start]))

    visited = set()
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # Right, Down, Left, Up

    while pq:
        curr = heapq.heappop(pq)

        if (curr.x, curr.y) in visited:
            continue
        visited.add((curr.x, curr.y))

        # Visualize the grid
        visualize_grid(grid, curr.path)

        if (curr.x, curr.y) == goal:
            print(f"✅ Robot reached the destination with cost: {curr.cost}")
            print("Path taken:", curr.path)
            return

        for dx, dy in directions:
            nx, ny = curr.x + dx, curr.y + dy
            if 0 <= nx < len(grid) and 0 <= ny < len(grid[0]) and grid[nx][ny] == 0:
                new_path = curr.path + [(nx, ny)]
                heapq.heappush(pq, GridState(nx, ny, curr.cost + 1, new_path))


# Visualization function
def visualize_grid(grid, path):
    grid_copy = np.array(grid)
    for x, y in path:
        grid_copy[x][y] = 2  # Mark the path in visualization

    plt.imshow(grid_copy, cmap="coolwarm", origin="upper")
    plt.xticks(range(len(grid[0])))
    plt.yticks(range(len(grid)))
    plt.grid(visible=True, color='black', linewidth=0.5)
    plt.pause(0.5)  # Animation pause for movement
    plt.clf()


# Example grid (0 = free space, 1 = obstacle)
grid = [
    [0, 0, 0, 0],
    [0, 1, 1, 0],
    [0, 0, 0, 0]
]

# Run the search with animation
plt.figure(figsize=(5, 5))
best_first_search_robot(grid, (0, 0), (2, 3))
plt.show()
