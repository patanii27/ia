import heapq

def a_star_cities_distance(graph, start, goal, heuristic_fn):
    open_set = []
    heapq.heappush(open_set, (0 + heuristic_fn(start), 0, start, [start]))
    visited = set()

    while open_set:
        f, g, current, path = heapq.heappop(open_set)
        if current == goal:
            return path, g
        if current in visited:
            continue
        visited.add(current)
        for neighbor, cost in graph[current]:
            if neighbor not in visited:
                heapq.heappush(open_set, (
                    g + cost + heuristic_fn(neighbor),
                    g + cost,
                    neighbor,
                    path + [neighbor]
                ))
    return None, float('inf')

# Example usage:
graph = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('C', 2), ('D', 5)],
    'C': [('A', 4), ('B', 2), ('D', 1)],
    'D': [('B', 5), ('C', 1)]
}

heuristic = {
    'A': 7,
    'B': 6,
    'C': 2,
    'D': 0
}

heuristic_fn = lambda node: heuristic[node]
path, cost = a_star_cities_distance(graph, 'A', 'D', heuristic_fn)
print("Shortest path:", path)
print("Total cost:", cost)
