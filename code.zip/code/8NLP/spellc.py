#pip install pyspellchecker

from spellchecker import SpellChecker

def spell_check(text):
    # Initialize the spell checker
    spell = SpellChecker()
    
    # Split the input text into words
    words = text.split()
    
    # Find words that are misspelled
    misspelled = spell.unknown(words)
    
    # Correct the misspelled words
    corrected = {}
    for word in misspelled:
        corrected[word] = spell.correction(word)
    
    return corrected

# Example usage
text = "I havv a gr8 day"
corrections = spell_check(text)
print("Corrections:", corrections)
