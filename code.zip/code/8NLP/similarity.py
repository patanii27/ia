#pip install scikit-learn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def similarity_score(text1, text2):
    # Convert the text to tf-idf vectors
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([text1, text2])
    
    # Calculate cosine similarity
    similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
    
    return similarity[0][0]

# Example usage
text1 = "I love programming in Python"
text2 = "Python programming is amazing"
similarity = similarity_score(text1, text2)
print(f"Cosine Similarity: {similarity}")
