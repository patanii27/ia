import heapq  # Importing heapq module to implement a priority queue
from copy import deepcopy  # Importing deepcopy to create deep copies of the board

class NPuzzleSolver:
    # This class is responsible for solving the N-Puzzle problem using A* algorithm

    def __init__(self, initial_board):
        # Constructor initializes the puzzle size and the initial state of the puzzle
        self.size = len(initial_board)  # Size of the board (e.g., 3 for a 3x3 puzzle)
        self.initial_state = self.Node(initial_board)  # Initialize the initial state of the puzzle
        
    class Node:
        # A Node class represents a state in the puzzle. Each node contains the current board, its parent (for path tracking),
        # the move made to reach this state, and the costs (g, h) for A* algorithm (g = cost from the start, h = heuristic)

        def __init__(self, board, parent=None, move=None):
            # Constructor initializes the board, its parent, the move made to reach this state,
            # and calculates the g and h values for A* algorithm
            self.board = board  # Current state of the board
            self.parent = parent  # Parent node (previous state)
            self.move = move  # The move that led to this state (Right, Down, Left, Up)
            self.g = 0 if parent is None else parent.g + 1  # g: Cost to reach this state from the start (1 for each move)
            self.h = self.calculate_heuristic()  # h: Heuristic value (Manhattan distance)
            self.blank_pos = self.find_blank()  # Position of the blank tile (0)

        def find_blank(self):
            # Find the position of the blank tile (represented by 0)
            for i in range(len(self.board)):
                for j in range(len(self.board)):
                    if self.board[i][j] == 0:
                        return (i, j)  # Return the coordinates (i, j) of the blank tile
            return None

        def calculate_heuristic(self):
            # Calculate the Manhattan distance heuristic
            h = 0
            n = len(self.board)  # The size of the board (n x n)
            for i in range(n):
                for j in range(n):
                    if self.board[i][j] != 0:  # Skip the blank tile
                        goal_row = (self.board[i][j] - 1) // n  # Row position in the goal state
                        goal_col = (self.board[i][j] - 1) % n  # Column position in the goal state
                        h += abs(i - goal_row) + abs(j - goal_col)  # Add the Manhattan distance for this tile
            return h  # Return the total heuristic value

        def is_goal(self):
            # Check if the current board state is the goal state
            n = len(self.board)
            num = 1  # The first number in the goal state should be 1
            for i in range(n):
                for j in range(n):
                    if i == n-1 and j == n-1:  # The last tile should be 0 (blank tile)
                        if self.board[i][j] != 0:
                            return False  # If the last tile is not 0, it's not the goal state
                    else:
                        if self.board[i][j] != num:
                            return False  # If any tile is not in its correct position, it's not the goal state
                        num += 1
            return True  # If all checks pass, return True (it's the goal state)

        def get_neighbors(self):
            # Generate all possible neighbor states by moving the blank tile in the 4 possible directions (Right, Down, Left, Up)
            neighbors = []
            i, j = self.blank_pos  # Position of the blank tile
            moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # Possible moves (Right, Down, Left, Up)
            
            for di, dj in moves:
                ni, nj = i + di, j + dj  # New position of the blank tile after the move
                if 0 <= ni < len(self.board) and 0 <= nj < len(self.board):
                    # Ensure the new position is within the bounds of the board
                    new_board = deepcopy(self.board)  # Create a deep copy of the current board
                    new_board[i][j], new_board[ni][nj] = new_board[ni][nj], new_board[i][j]  # Swap the blank tile with the adjacent tile
                    neighbors.append(NPuzzleSolver.Node(new_board, self, (di, dj)))  # Add the new state as a neighbor
            return neighbors  # Return the list of neighboring nodes

        def __lt__(self, other):
            # Comparison function used by heapq to order nodes based on their f value (f = g + h)
            return (self.g + self.h) < (other.g + other.h)

        def __eq__(self, other):
            # Nodes are considered equal if they have the same board configuration
            return self.board == other.board

        def __hash__(self):
            # Make the node hashable so it can be added to a set (used for closed set)
            return hash(tuple(tuple(row) for row in self.board))

        def __str__(self):
            # String representation of the board (for printing purposes)
            return '\n'.join([' '.join(map(str, row)) for row in self.board])

    def solve(self):
        # A* search algorithm to solve the N-Puzzle
        open_set = []  # A priority queue (min-heap) for exploring nodes
        heapq.heappush(open_set, self.initial_state)  # Push the initial state into the open set
        closed_set = set()  # A set for keeping track of explored nodes (states)
        
        while open_set:
            # While there are nodes to explore, pop the one with the lowest f value
            current = heapq.heappop(open_set)
            
            if current.is_goal():
                # If the current state is the goal, reconstruct and return the solution path
                path = []
                while current.parent is not None:  # Backtrack from the goal to the start
                    path.append(current)
                    current = current.parent
                path.append(current)  # Add the start node
                path.reverse()  # Reverse the path to show it from start to goal
                return path  # Return the solution path
                
            closed_set.add(current)  # Mark the current node as explored
            
            # For each neighbor of the current node, process it
            for neighbor in current.get_neighbors():
                if neighbor in closed_set:
                    continue  # Skip if the neighbor has already been explored
                
                if neighbor not in open_set:
                    heapq.heappush(open_set, neighbor)  # Add the neighbor to the open set
                else:
                    # If the neighbor is already in the open set, check if we found a better path
                    for node in open_set:
                        if node == neighbor and node.g > neighbor.g:
                            node.g = neighbor.g  # Update the g value if a better path is found
                            node.parent = neighbor.parent  # Update the parent node
                            heapq.heapify(open_set)  # Re-heapify the open set
                            break
        return None  # If no solution is found, return None

# Example usage
initial_board = [
    [1, 2, 3],
    [4, 0, 6],
    [7, 5, 8]
]

solver = NPuzzleSolver(initial_board)  # Create an NPuzzleSolver object with the initial board
solution = solver.solve()  # Find the solution

if solution:
    print("Solution found in", len(solution)-1, "moves:")
    for i, state in enumerate(solution):
        if i > 0:
            print(f"\nMove {i}: {state.move}")  # Print the move that led to the current state
        print(state.board)  # Print the board at each step
else:
    print("No solution found")  # If no solution exists, print this message
