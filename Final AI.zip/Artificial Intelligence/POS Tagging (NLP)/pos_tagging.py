import re

def fill_missing_tags(tagged_sentence):
    # Extract all existing POS tags (excluding ?? and ???)
    existing_tags = set(re.findall(r'/([A-Z]{2,4})', tagged_sentence))
    existing_tags.discard('??')
    existing_tags.discard('???')

    # Define a dictionary for guessing POS tags
    # You can expand this dictionary as needed
    guess_tags = {
        "system": "NN",    # noun
        "star": "NN",      # noun
        "caught": "VBN",   # past participle verb
        "fire": "NN",      # noun
        "planet": "NN",
        "Jupiter": "NNP",  # proper noun
        "called": "VBN",
        "moons": "NNS",
        "never": "RB",
        "minisolar": "JJ"
    }

    # Function to replace missing tags
    def replacer(match):
        word = match.group(1)
        missing_tag = match.group(2)
        guessed_tag = guess_tags.get(word.lower(), 'NN')  # default to NN
        if guessed_tag in existing_tags:
            return f"{word}/{guessed_tag}"
        return f"{word}/{guessed_tag}"  # Still return guessed tag even if not in original tags

    # Replace all ?? or ??? tags with guessed values
    filled_sentence = re.sub(r'(\w+)/(\?{2,3})', replacer, tagged_sentence)

    return filled_sentence

# === User Input Section ===
print("Enter a POS-tagged sentence with missing tags (use ?? or ???):")
input_sentence = ""
print("(End your input with a blank line)")

# Allow multiline input
while True:
    line = input()
    if line.strip() == "":
        break
    input_sentence += line + "\n"

# Fill missing tags and display result
output_sentence = fill_missing_tags(input_sentence.strip())
print("\nCorrected Sentence:\n")
print(output_sentence)
