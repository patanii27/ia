from collections import deque
import networkx as nx
import matplotlib.pyplot as plt

def bfs(graph, source, parent, distance):
    q = deque()
    distance[source] = 0
    q.append(source)

    while q:
        node = q.popleft()
        for neighbor in graph[node]:
            if distance[neighbor] == float('inf'):
                parent[neighbor] = node
                distance[neighbor] = distance[node] + 1
                q.append(neighbor)

def reconstruct_path(parent, dest):
    path = []
    current = dest
    while current != -1:
        path.append(current)
        current = parent[current]
    path.reverse()
    return path

def visualize_graph(graph_adj_list, path):
    G = nx.Graph()

    for u in range(len(graph_adj_list)):
        for v in graph_adj_list[u]:
            G.add_edge(u, v)

    pos = nx.spring_layout(G)

    # Draw full graph
    nx.draw(G, pos, with_labels=True, node_color='lightgray', edge_color='gray', node_size=800, font_weight='bold')

    # Highlight the shortest path
    path_edges = list(zip(path, path[1:]))
    nx.draw_networkx_nodes(G, pos, nodelist=path, node_color='skyblue')
    nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color='blue', width=2)

    plt.title("Graph with Shortest Path Highlighted")
    plt.show()

def print_shortest_distance(graph, source, dest, num_vertices):
    parent = [-1] * num_vertices
    distance = [float('inf')] * num_vertices

    bfs(graph, source, parent, distance)

    if distance[dest] == float('inf'):
        print("❌ No path found between Source and Destination.")
        return

    path = reconstruct_path(parent, dest)

    print(f"\n✅ Shortest Path from {source} to {dest} (length {distance[dest]}):")
    print(" -> ".join(map(str, path)))

    visualize_graph(graph, path)

if __name__ == "__main__":
    try:
        V = int(input("Enter the number of vertices: "))
        E = int(input("Enter the number of edges: "))

        graph = [[] for _ in range(V)]

        print("Enter the edges (format: u v):")
        for _ in range(E):
            u, v = map(int, input().split())
            if 0 <= u < V and 0 <= v < V:
                graph[u].append(v)
                graph[v].append(u)
            else:
                print("Invalid edge! Vertex out of range.")

        S = int(input("Enter source vertex: "))
        D = int(input("Enter destination vertex: "))

        if 0 <= S < V and 0 <= D < V:
            print_shortest_distance(graph, S, D, V)
        else:
            print("❌ Invalid source or destination vertex.")

    except ValueError:
        print("❌ Invalid input! Please enter integers only.")
