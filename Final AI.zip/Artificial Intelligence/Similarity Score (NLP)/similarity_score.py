from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Input documents from user
n = int(input("Enter number of documents: "))
documents = []
for i in range(n):
    doc = input(f"Enter document {i+1}: ")
    documents.append(doc)

# Create TF-IDF vectors with English stop words removed
vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = vectorizer.fit_transform(documents)

# Compute cosine similarities with the first document
cosine_similarities = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:]).flatten()

# Display similarities as percentages
print("\nSimilarity with Document 1:")
for i, score in enumerate(cosine_similarities, start=2):
    print(f"Document {i}: {score * 100:.2f}%")

# Find the most similar document (if more than one exists)
if cosine_similarities.size > 0:
    most_similar_index = cosine_similarities.argmax() + 2  # +2 to account for skipping doc 1 and 1-based index
    print(f"\nMost similar document to Document 1 is Document {most_similar_index}")
    print(f"Similarity Score: {cosine_similarities.max() * 100:.2f}%")
else:
    print("\nNot enough documents to compare.")
